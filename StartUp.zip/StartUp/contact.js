
function SubForm(){
    $.ajax({
        url:'https://api.apispreadsheets.com/data/rNEyWMrkkqO61dSc/',
        
        type:'post',
        data:$("#myform").serializeArray(),
        success: function(){
          alert("Form Data Submitted :)")
        },
        error: function(){
          alert("There was an error :(")
        }
    });
}